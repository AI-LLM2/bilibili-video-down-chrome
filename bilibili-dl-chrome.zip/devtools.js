chrome.devtools.panels.create(
  "Bilibili Downloader",
  "icon.png",
  "panel.html",
  function(panel) {
    console.log("DevTools panel created");
  }
); 